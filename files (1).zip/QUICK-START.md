# 🚀 دليل سريع - 5 خطوات فقط!

## المطلوب منك فقط:

### 1️⃣ إنشاء Firebase (5 دقائق)
- اذهب: https://console.firebase.google.com
- أنشئ مشروع جديد
- فعّل Realtime Database (وضع الاختبار)
- انسخ إعدادات التطبيق

### 2️⃣ تحديث الملف (دقيقتين)
- افتح `family-tree.html`
- ابحث عن `const firebaseConfig`
- استبدل بإعداداتك من Firebase
- احفظ الملف

### 3️⃣ إنشاء GitHub (3 دقائق)
- اذهب: https://github.com
- سجل حساب جديد
- أنشئ مستودع باسم `family-tree`

### 4️⃣ رفع الملف (دقيقة)
- اضغط "Upload files"
- ارفع `family-tree.html`
- Commit changes

### 5️⃣ تفعيل GitHub Pages (دقيقتين)
- Settings > Pages
- Source: main branch
- احفظ
- انتظر دقيقتين

## ✅ جاهز!

رابطك سيكون:
```
https://اسم-المستخدم.github.io/family-tree/family-tree.html
```

شاركه مع عائلتك واستمتعوا! 🎉

---

**مشكلة؟** راجع `setup-guide.md` للتفاصيل الكاملة
